<?php get_header(); ?>
	<div id="header">
		<h1>
			<a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a>
		</h1>
	</div><!--end header-->
		<div id="single-content">
			<?php if(have_posts()) : while (have_posts()) : the_post(); ?>
				<div id="post-<?php the_ID(); ?>" class="single-post">
					<div class="post-info">
						<span class="post-date"><?php the_time('Y/m/d  G:i'); ?></span>
						<span class="post-review"><?php _e( 'Comments','iphoto' ); ?>（<?php comments_popup_link('0', '1', '%'); ?>）</span>
					</div><!--end post-info -->
					<div class="navigation">
						<div class="prev"><?php next_post_link('%link', '<em class="tc"></em><span>Prev</span>') ?></div>
						<div class="next"><?php previous_post_link('%link', '<em class="bc"></em><span>Next</span>') ?></div>
					</div><!--end navigation -->
					<div class="post-content">
						<?php the_content(); ?>
					</div><!--end post-content -->
				</div><!--end single-post -->
			<?php endwhile; endif; ?>
			<div id="leave-a-comment"><h3><?php comments_popup_link('0 Comment', '1 Comment', '% Comments'); ?></h3></div>
			<div id="comments">
				<?php comments_template('', true); ?>
			</div><!--end comments-->
		</div><!--end single-content-->
<?php get_footer(); ?>