<?php
add_action('admin_menu', 'iphoto_page');
function iphoto_page (){
	if ( count($_POST) > 0 && isset($_POST['iphoto_settings']) ){
		$options = array ('rss', 'keywords', 'description', 'analytics', 'lib', 'slimbox', 'copyright');
		foreach ( $options as $opt ){
			delete_option ( 'iphoto_'.$opt, $_POST[$opt] );
			add_option ( 'iphoto_'.$opt, $_POST[$opt] );	
		}
	}
	add_theme_page('iPhoto '.__('Theme Options','iphoto'), 'iPhoto '.__('Theme Options','iphoto'), 'edit_themes', basename(__FILE__), 'iphoto_settings');
}
function iphoto_settings(){?>
 <style type="text/css">
#wpwrap,#adminmenu .wp-submenu ul,#wpcontent{background-color:#FAFAFA}
#wphead,#contextual-help-link-wrap{display:none}
.wrap{padding:10px; font-size:12px; line-height:24px;}
body,td,input,textarea,em{font-family:'Century Gothic', 'Microsoft YaHei', Arial, Verdana, Tahoma, sans-serif;}
strong{ color:#666}
textarea{ width:100%; margin:0 20px 0 0;  overflow:auto}
fieldset{ border:1px solid #ddd;margin:5px 0 10px;padding:5px 15px 15px;-moz-border-radius:3px;-khtml-border-radius:3px;-webkit-border-radius:3px;border-radius:3px; width:600px}
fieldset legend{padding:0 5px;font-size:14px;font-weight:700;cursor:pointer;margin-left:5px;color:#21759B;text-shadow: rgba(255, 255, 255, 1) 0 1px 0;}
fieldset .line{border-bottom:1px solid #e5e5e5;padding-bottom:15px;}
.form-table{display:none;margin:0;border:0}
textarea,input[type="text"]{font-size:11px;border:1px solid #DFDFDF;background:#FFF;}
input:focus,textarea:focus{border-color:#19A2DE;-webkit-box-shadow: 0 0 8px rgba(25,162,222, 0.1);-moz-box-shadow: 0 0 8px rgba(25,162,222, 0.1);box-shadow: 0 0 8px rgba(25,162,222, 0.1);outline:none;}
legend:hover,a:hover{color: #BC0B0B;;}
</style>
<script type="text/javascript">jQuery(document).ready(function($){$('legend').click(function(){$(this).next('table').show()});})</script>
<div class="wrap">
<?php _e( '<h2>iPhoto Theme Options</h2>','iphoto' ); ?>
<form method="post" action="">
	<fieldset>
		<legend ><?php _e( 'jQuery Effect','iphoto' ); ?></legend>
		<table class="form-table">
			<tr><td>
				<em><?php _e( 'iPhoto use the default jquery 1.4.4 that contained in the theme, you can also use the Google one.','iphoto' ); ?></em><br/>
				<label><input name="lib" type="checkbox" id="lib" value="1" <?php if (get_option('iphoto_lib')!='') echo 'checked="checked"'; ?>/><?php _e( 'Load the jQuery Library supported by Google','iphoto' ); ?></label>
			</td></tr>
			<tr><td>
				<em><?php _e( 'iPhoto has already containered Slimbox2.0 slide effect, maybe you want to try it, and you should close relative plugin','iphoto' ); ?></em><br/>
				<label><input name="slimbox" type="checkbox" id="slimbox" value="1" <?php if (get_option('iphoto_slimbox')!='') echo 'checked="checked"'; ?>/><?php _e( 'Activate Slimbox2.0 slide effect','iphoto' ); ?></label>
			</td></tr>
		</table>
	</fieldset>
	<fieldset>
	<legend ><?php _e( 'Website Information','iphoto' ); ?></legend>
		<table class="form-table">
			<tr><td>
				<?php _e( '<em>Keywords, separate by English commas. like iCold, Computer, Software</em>','iphoto' ); ?><br/>
				<textarea name="keywords" id="keywords" rows="1" cols="70" style="font-size:11px;width:100%;"><?php echo get_option('iphoto_keywords'); ?></textarea>	
			</td></tr>
			<tr><td>
				<?php _e( '<em>Description, explain what this site is about. like The iCold, focus on the Internet</em>','iphoto' ); ?><br/>
				<textarea name="description" id="description" rows="3" cols="70" style="font-size:11px;width:100%;"><?php echo get_option('iphoto_description'); ?></textarea>		
			</td></tr>
		</table>
	</fieldset>
	<fieldset>
	<legend ><?php _e( 'Analytics Code','iphoto' ); ?></legend>
		<table class="form-table">
			<tr><td>
				<?php _e( 'You can get your Google Analytics code <a target="_blank" href="https://www.google.com/analytics/settings/check_status_profile_handler">here</a>.','iphoto' ); ?></label><br>
				<textarea name="analytics" id="analytics" rows="5" cols="70" style="font-size:11px;width:100%;"><?php echo stripslashes(get_option('iphoto_analytics')); ?></textarea>
			</td></tr>
		</table>
	</fieldset>
	<fieldset>
	<legend ><?php _e( 'Footer Copyright','iphoto' ); ?></legend>
		<table class="form-table">
			<tr><td>
				<textarea name="copyright" id="copyright" rows="5" cols="70" style="font-size:11px;width:100%;"><?php if(stripslashes(get_option('iphoto_copyright'))!=''){echo stripslashes(get_option('iphoto_copyright'));}else{echo 'Copyright &copy; '.date("Y").' '.'<a href="'.home_url( '/' ).'" title="'.esc_attr( get_bloginfo( 'name') ).'">'.esc_attr( get_bloginfo( 'name') ).'</a> All rights reserved';}?></textarea>
				<br/><em><?php _e( '<b>Preview</b>','iphoto' ); ?><span> : </span><span><?php if(stripslashes(get_option('iphoto_copyright'))!=''){echo stripslashes(get_option('iphoto_copyright'));}else{echo 'Copyright &copy; '.date("Y").' '.'<a href="'.home_url( '/' ).'" title="'.esc_attr( get_bloginfo( 'name') ).'">'.esc_attr( get_bloginfo( 'name') ).'</a> All rights reserved';}?></span></em>
			</td></tr>
		</table>
	</fieldset>
	<p class="submit">
		<input type="submit" name="Submit" class="button-primary" value="<?php _e( 'Save Options','iphoto' ); ?>" />
		<input type="hidden" name="iphoto_settings" value="save" style="display:none;" />
	</p>
</form>
	<fieldset>
	<legend style="margin-left:5px; padding:0 5px;color:#464646;text-shadow: rgba(255, 255, 255, 1) 0 1px 0;"><?php _e( '<h2>iPhoto Theme Declare</h2>','iphoto' ); ?></legend>
		<table class="form-table" style="display:block">
			<tr><td>
			<?php _e('iPhoto is Created, Developed and maintained by <a href="http://icold.me/">iCold. If you like iPhoto, please donate. It will help in developing new features and versions.</a>','iphoto' ); ?>
			<p  id="release" style="text-indent: 2em;"><?php _e('Alipay', 'iphoto');?>:</strong> <a href="http://www.alipay.com" target="_blank" title="Alipay">afcold@gmail.com</a></p>
			<h3 style="color:#333" id="introduce"><?php _e( 'Introduction','iphoto' ); ?></h3>
			<p style="text-indent: 2em"><?php _e( 'iPhoto is evolved from one theme of Tumblr. I just turned it into a photo theme which can be used at wordpress.','iphoto' ); ?></p>
			<h3 style="color:#333"><?php _e( 'Published Address','iphoto' ); ?></h3>
			<p  id="release" style="text-indent: 2em;"><a href="http://icold.me/wordpress-theme-iphoto/" target="_blank">http://icold.me/wordpress-theme-iphoto/</a></p>

			<h3 style="color:#333"><?php _e( 'Preview Address','iphoto' ); ?></h3>
			<p  id="preview" style="text-indent: 2em;"><a href="http://icold.me/photo/" target="_blank">http://icold.me/photo/</a></p>

			<h3 style="color:#333" id="bug"><?php _e( 'Report Bugs','iphoto' ); ?></h3>
			<?php _e( 'Mailto <a href="mailto:icold.me@gmail.com">icold.me@gmail.com</a> or leave a message at <a href="http://icold.me" target="_blank">http://icold.me</a>。','iphoto' ); ?>
			</td></tr>
		</table>
	</fieldset>
</div>
<?php
}
?>