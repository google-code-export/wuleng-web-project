	<div id="footer">
		<p><?php if(stripslashes(get_option('iphoto_copyright'))!=''){echo stripslashes(get_option('iphoto_copyright'));}else{echo 'Copyright &copy; '.date("Y").' '.'<a href="'.home_url( '/' ).'" title="'.esc_attr( get_bloginfo( 'name') ).'">'.esc_attr( get_bloginfo( 'name') ).'</a> All rights reserved';}?></p>
		<p>Powered by <a href="http://wordpress.org/" title="Wordpress">WordPress <?php bloginfo('version');?></a>  |  Writed by <a href="http://icold.me/" title="iCold">iCold</a> </p>
	</div><!--end footer-->
</div><!--end wrapper-->
<?php wp_footer(); ?>
<?php if(get_option('iphoto_lib')!="") : ?>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script>
<?php else : ?>	
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/includes/jquery.min.js"></script>
<?php endif; ?>
<?php if ( is_home() ){ ?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/includes/index.js"></script>
<?php } elseif (is_singular()){ ?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/includes/single.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/includes/comments-ajax.js"></script>
<?php if(get_option('iphoto_slimbox')!="") : ?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/includes/slimbox2.js"></script>
<?php endif; ?>
<?php }?>
<?php if (get_option('iphoto_analytics')!="") {?>
<?php echo stripslashes(get_option('iphoto_analytics')); ?>
<?php }?>
</body>
</html>
