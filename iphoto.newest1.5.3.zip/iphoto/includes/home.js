﻿function getElementsByClassName(className,ele,tagName){
	var a=[],eles=null;
	if(ele){
		if(tagName){
			eles= ele.getElementsByTagName(tagName);
		}else{
			eles=ele.getElementsByTagName('*');
		}
	}else{
		eles=document.getElementsByTagName('*');
	}
	for(var i=0;i<eles.length;i++){
		if(eles[i].className.search(new RegExp("\\b"+className+"\\b"))!=-1){
			a.push(eles.item(i));
		}
	}
	return a;
}
var imageReady=(function(){
        var list=[],
            timer=null,
            tick=function(){
                for(var i=0;i<list.length;i++){
                    list[i].end?list.splice(i--,1):check.call(list[i],null);
                }
                list.length && (timer=setTimeout(tick,50)) || (timer=null);
            },
            /** overflow: 检测图片尺寸的改变
              *  img.__width,img.__height: 初载入时的尺寸
              */
            check=function(){
                if(this.width!==this.__width || this.height!==this.__height || this.width*this.height>1024){
                    this.onready.call(this,null);
                    this.end=true;
                }
            };
            return function(img, onready, onload, onerror){
                onready=onready || new Function();
                onload=onload || new Function();
                onerror=onerror || new Function();
                if(typeof img == 'string'){
                    var src=img,
                        img=new Image();
                    img.src=src;
                }
                if(img.complete){
                    onready.call(img,null);
                    onload.call(img,null);
                    return true;
                }
                img.__width=img.width;
                img.__height=img.height;
                img.onready=onready;
                check.call(img,null);
                img.onload=img.onreadystatechange=function(){
                    if(img&&img.readyState&&img.readyState!='loaded'&&img.readyState!='complete'){return;}
                    onload.call(img,null);
                    img=img.onload=img.onerror=img.onreadystatechange=null;
                }
                img.onerror=function(){
                    onerror.call(img,null);
                    img.end=true;
                    img=img.onload=img.onerror=img.onreadystatechange=null;
                }
                if(!img.end){
                    list.push(img);
                    if(timer===null) timer=setTimeout(tick,50);
                }
            }
    })();
var ele=document.getElementById('container'),
	thumb=getElementsByClassName('post-thumbnail',ele,'div'),tn=thumb.length;
for(var i=0;i<tn;i++){
	img=thumb[i].getElementsByTagName('img');
	var url=img[0].getAttribute('src');
	imageReady(url,function(){
		var x=this.width,y=this.height,w=450,h;
		h=Math.round(w*y/x);
		thumb[i].style.width="450px";
		thumb[i].style.height=h+"px"
	});


}