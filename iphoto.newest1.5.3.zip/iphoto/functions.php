<?php
load_theme_textdomain( 'iphoto', TEMPLATEPATH . '/languages' );
add_custom_background();
function post_thumbnail($width = 450,$flag){
	global $post;
	$permalink = get_permalink($post->ID);
	$title = $post->post_title;
	$post_img = '';
	ob_start();
	ob_end_clean();
	$output = preg_match_all('/<img(.[^<]*)src=\"?(.[^<\"]*)\"?(.[^<]*)\/?>/is ', $post->post_content, $matches , PREG_SET_ORDER);
	$post_img_src = $matches [0][2];
	$cnt = count( $matches );
	if(empty($post_img_src)){
		$post_img = '<div class="title"><a href="' . $permalink . '" title="'.$post->post_title.'">'.$post->post_title.'</a></div>';
	}else{
		if( $cnt > 1){
			$post_img = '<a href="' . $permalink . '" title="'.$post->post_title.'"><img src="'.get_bloginfo("template_url").'/timthumb.php?src='.$post_img_src.'&amp;w='.$width.'&amp;zc=1"  alt="'.$post->post_title.'" /><span class="count">'.$cnt.' Photos</span><span class="bg"></span></a>'; 
		}else{
			$post_img = '<a href="' . $permalink . '" title="'.$post->post_title.'"><img src="'.get_bloginfo("template_url").'/timthumb.php?src='.$post_img_src.'&amp;w='.$width.'&amp;zc=1"  alt="'.$post->post_title.'" /></a>'; 
		}
	}
	if($flag==1){
		return $post_img;
	}else{
		return $cnt;
	}
}
function pagenavi( $p = 2 ) { 
	if ( is_singular() ) return;
	global $wp_query, $paged;
	$max_page = $wp_query->max_num_pages;
	if ( $max_page == 1 ) return; 
	if ( empty( $paged ) ) $paged = 1;
	if ( $paged > 1 ) echo "<a id='prev' title='Prev' href='", esc_html( get_pagenum_link( $paged - 1 ) ), "'>&lt;&lt;</a> ";
	echo "<span>" . $paged . " / " . $max_page . "</span>";
	if ( $paged < $max_page  ) echo "<a id='next' title='Next' href='", esc_html( get_pagenum_link( $paged + 1) ), "'>&gt;&gt;</a> ";
}
function iphoto_comment($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment;
?>
	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>" >
		<div id="comment-<?php comment_ID(); ?>" class="comment-body">
			<div class="commentmeta"><?php echo get_avatar( $comment->comment_author_email, $size = '48'); ?></div>
				<?php if ($comment->comment_approved == '0') : ?>
				<em><?php _e('Your comment is awaiting moderation.') ?></em><br />
				<?php endif; ?>
			<div class="commentmetadata">&nbsp;-&nbsp;<?php printf(__('%1$s at %2$s'), get_comment_date('Y.n.d'),  get_comment_time('G:i'));?></div>
			<div class="reply"><?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth'], 'reply_text' => __('Reply')))) ?></div>
			<div class="vcard"><?php printf(__('%s'), get_comment_author_link()) ?></div>
			<?php comment_text() ?>
		</div>
<?php
}
require_once(TEMPLATEPATH . '/theme-options.php');
?>