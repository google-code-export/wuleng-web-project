<?php get_header(); ?>
	<div id="container">
		<div id="header">
			<h1>
				<a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a>
			</h1>
		</div><!--end header-->
	<?php if(have_posts()) : while (have_posts()) : the_post(); ?>
		<div id="post-<?php the_ID(); ?>" class="index-post">
			<div class="post-thumbnail">
				<?php post_thumbnail();?>
			</div><!--end post_thumbnail -->
			<div class="post-content">
				<p><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 500,"..."); ?></p>
			</div><!--end post-content -->
			<div class="post-info">
				<span class="post-date"><?php the_time('Y/m/d  G:i'); ?></span>
				<span class="post-review"><?php _e( 'Comments','iphoto' ); ?>（<?php comments_popup_link('0', '1', '%'); ?>）</span>
	        </div><!--end post-info -->
		</div><!--end index-post -->
	<?php endwhile; endif; ?>
	</div><!--end container-->
	<div class="clear"></div>
	<div id="pagenavi">
		<?php pagenavi();?>
	</div>
<?php get_footer(); ?>